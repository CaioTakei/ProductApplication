﻿using Microsoft.AspNetCore.Mvc;
using ProductApplication.Models;
using ProductApplication.Repository;

namespace ProductApplication.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProductRepository _productRepository;
        public ProductController(IProductRepository productrepository) 
        {
            _productRepository = productrepository;
        }
        public IActionResult Index()
        {
            List<ProductModel> products = _productRepository.List();
            return View(products);
        }

        public IActionResult Create()
        {
            return View();
        }

        //[HttpPost]
        public IActionResult Edit(int id)
        {
            ProductModel productModel = _productRepository.Get(id);
            return View(productModel);
        }

        public IActionResult Exclude(int id)
        {
            ProductModel productModel = _productRepository.Get(id);
            return View(productModel);
        }

        public IActionResult Remove(int id)
        {
            try
            {
                bool excluded = _productRepository.Remove(id);
                if (excluded)
                {
                    TempData["Success"] = "Produto removido com sucesso";                    
                }
                else 
                {
                    TempData["Error"] = "Não foi possível remover o produto";
                }

                return RedirectToAction("Index");
            }
            catch (System.Exception error)
            {
                TempData["Error"] = $"Não foi possível remover o produto, detalhe: {error.Message}";
                return RedirectToAction("Index");
            }
        }

        [HttpPost]
        public IActionResult Create(ProductModel productModel)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _productRepository.Add(productModel);
                    TempData["Success"] = "Produto cadastrado com sucesso";
                    return RedirectToAction("Index");
                }

                return View(productModel);
            }
            catch (System.Exception error) 
            {
                TempData["Error"] = $"Não foi possível cadastrar o produto, detalhe: {error.Message}";
                return RedirectToAction("Index");
            }
        }

        [HttpPost]
        public IActionResult Update(ProductModel productModel)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    _productRepository.Update(productModel);
                    TempData["Success"] = "Produto alterado com sucesso";
                    return RedirectToAction("Index");
                }

                return View("Edit", productModel);
            }
            catch (System.Exception error)
            {
                TempData["Error"] = $"Não foi possível alterar o produto, detalhe: {error.Message}";
                return RedirectToAction("Index");
            }
        }
    }
}

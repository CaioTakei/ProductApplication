﻿using Microsoft.AspNetCore.Mvc;
using ProductApplication.Models;
using ProductApplication.Repository;

namespace ProductApplication.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProductRepository _productRepository;
        public ProductController(IProductRepository productrepository) 
        {
            _productRepository = productrepository;
        }
        public IActionResult Index()
        {
            List<ProductModel> products = _productRepository.List();
            return View(products);
        }

        public IActionResult Create()
        {
            return View();
        }

        //[HttpPost]
        public IActionResult Edit(int id)
        {
            ProductModel productModel = _productRepository.Get(id);
            return View(productModel);
        }

        public IActionResult Exclude(int id)
        {
            ProductModel productModel = _productRepository.Get(id);
            return View(productModel);
        }

        public IActionResult Remove(int id)
        {
            _productRepository.Remove(id);
            return RedirectToAction("Index");            
        }

        [HttpPost]
        public IActionResult Create(ProductModel productModel)
        {
            _productRepository.Add(productModel);
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult Update(ProductModel productModel)
        {
            _productRepository.Update(productModel);
            return RedirectToAction("Index");
        }
    }
}

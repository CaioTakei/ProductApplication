﻿using ProductApplication.Models;

namespace ProductApplication.Repository
{
    public interface IProductRepository
    {
        ProductModel Add(ProductModel productModel);
        List<ProductModel> List();
        ProductModel Get(int id);
        ProductModel Update(ProductModel productModel);
        bool Remove(int id);
    }
}

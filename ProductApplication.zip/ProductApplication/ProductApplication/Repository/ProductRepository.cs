﻿using ProductApplication.Data;
using ProductApplication.Models;

namespace ProductApplication.Repository
{
    public class ProductRepository : IProductRepository
    {
        private readonly DataContext _dataContext;
        public ProductRepository(DataContext dataContext) 
        { 
            _dataContext = dataContext;
        }
        public ProductModel Add(ProductModel productModel)
        {
            _dataContext.Produtos.Add(productModel);
            _dataContext.SaveChanges();
            return productModel;
        }

        public ProductModel Get(int id)
        {
            return _dataContext.Produtos.FirstOrDefault(x => x.Id == id);
        }

        public List<ProductModel> List()
        {
            return _dataContext.Produtos.ToList();
        }

        public ProductModel Update(ProductModel productModel)
        {
            ProductModel product = Get(productModel.Id);
            if (product == null) throw new System.Exception("ocorreu um erro ao atualizar o Produto");

            product.Name = productModel.Name;
            product.Description = productModel.Description;
            product.Price = productModel.Price;

            _dataContext.Produtos.Update(product);
            _dataContext.SaveChanges();
            
            return product;            
        }

        public bool Remove(int id)
        {
            ProductModel product = Get(id);
            if (product == null) throw new System.Exception("ocorreu um erro ao excluir o Produto");

            _dataContext.Produtos.Remove(product);
            _dataContext.SaveChanges();
            return true;
        }        
    }
}

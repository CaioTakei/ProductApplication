﻿using Microsoft.EntityFrameworkCore;
using ProductApplication.Models;

namespace ProductApplication.Data
{
    public class DataContext :DbContext  
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options)
        {
        }

        public DbSet<ProductModel> Produtos { get; set; }

    }
}
